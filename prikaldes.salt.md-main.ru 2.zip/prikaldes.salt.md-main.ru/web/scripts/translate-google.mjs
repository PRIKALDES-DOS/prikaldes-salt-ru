// Create or top up a locale catalog through Google's public translation
// endpoint. This is an optional, no-key alternative to translate.mjs; it sends
// interface source strings only, never workspace data. Review generated entries
// before shipping them to users.
//
//   node scripts/translate-google.mjs ru

import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const localeDir = join(import.meta.dirname, '../src/locales');
const srcDir = join(import.meta.dirname, '../src');
const locale = process.argv[2];
if (!locale || !/^[a-z]{2,3}$/.test(locale)) {
  console.error('Usage: node scripts/translate-google.mjs <locale>');
  process.exit(2);
}

function walk(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const path = join(dir, entry.name);
    return entry.isDirectory() ? walk(path) : /\.tsx?$/.test(entry.name) ? [path] : [];
  });
}

function pluralSources() {
  const sources = new Map();
  const call = /\bplural\(\s*[^,]+,\s*(['"`])((?:\\.|(?!\1)[^\\])*)\1\s*,\s*(['"`])((?:\\.|(?!\3)[^\\])*)\3/g;
  for (const path of walk(srcDir)) {
    for (const match of readFileSync(path, 'utf8').matchAll(call)) {
      sources.set(match[4], match[2]);
    }
  }
  return sources;
}

const refreshPlurals = process.argv.includes('--refresh-plurals');
const keyListArg = refreshPlurals ? '__none__' : locale;
const keys = Object.keys(
  JSON.parse(execFileSync(process.execPath, ['scripts/check-i18n.mjs', '--missing', keyListArg], { encoding: 'utf8' })),
);
const outPath = join(localeDir, `${locale}.json`);
const existing = existsSync(outPath) ? JSON.parse(readFileSync(outPath, 'utf8')) : {};
const missing = keys.filter((key) => !(key in existing) || (refreshPlurals && key.includes('{n}')));
if (!missing.length) {
  console.log(`${locale}: catalog is current.`);
  process.exit(0);
}

const pluralMap = pluralSources();
const jobs = [];
for (const key of missing) {
  if (key.includes('{n}')) {
    const singular = pluralMap.get(key);
    if (singular) {
      jobs.push({ key, category: 'one', text: singular.replaceAll('{n}', '1'), restore: '1' });
      for (const [category, number] of [['few', '2'], ['many', '5'], ['other', '1.5']]) {
        jobs.push({ key, category, text: key.replaceAll('{n}', number), restore: number });
      }
      continue;
    }
  }
  jobs.push({ key, category: '', text: key });
}

function batches(items) {
  const out = [];
  let batch = [];
  let size = 0;
  for (const item of items) {
    const nextSize = item.text.length + 48;
    if (batch.length && (batch.length >= 12 || size + nextSize > 2400)) {
      out.push(batch);
      batch = [];
      size = 0;
    }
    batch.push(item);
    size += nextSize;
  }
  if (batch.length) out.push(batch);
  return out;
}

async function translateBatch(batch, batchNo) {
  const marker = (i) => `ZXQ_${batchNo}_${i}__QXZ`;
  const tokens = [];
  const protectedTexts = batch.map((item, i) => {
    const text = item.text.replace(/\{\w+\}/g, (placeholder) => {
      const token = `ZXQPH${tokens.length}QXZ`;
      tokens.push([token, placeholder]);
      return token;
    });
    return `${text}\n${marker(i)}\n`;
  });
  const query = protectedTexts.join('');
  const url = new URL('https://translate.googleapis.com/translate_a/single');
  for (const [name, value] of Object.entries({ client: 'gtx', sl: 'en', tl: locale, dt: 't', q: query })) {
    url.searchParams.set(name, value);
  }
  let lastError;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      // Python's standard-library urllib works in environments where Node's
      // fetch is behind a proxy that it does not inherit.
      const raw = execFileSync(
        'python3',
        ['-c', 'import sys,urllib.request; print(urllib.request.urlopen(sys.stdin.read(), timeout=25).read().decode())'],
        { input: url.toString(), encoding: 'utf8', timeout: 30000 },
      );
      const data = JSON.parse(raw);
      const translated = (data[0] ?? []).map((part) => part[0] ?? '').join('');
      const pieces = translated.split(/ZXQ_\d+_\d+__QXZ/).map((part) => part.trim());
      if (pieces.length === batch.length + 1 && pieces.at(-1) === '') pieces.pop();
      if (pieces.length !== batch.length) {
        throw new Error(`translation response changed batch boundaries (${pieces.length}/${batch.length}): ${translated.slice(0, 300)}`);
      }
      return pieces.map((piece) => {
        let result = piece;
        for (const [token, placeholder] of tokens) result = result.replaceAll(token, placeholder);
        return result;
      });
    } catch (error) {
      lastError = error;
      await new Promise((resolve) => setTimeout(resolve, 500 * (attempt + 1)));
    }
  }
  throw new Error(`batch ${batchNo + 1} failed: ${lastError}`);
}

const translated = {};
const allBatches = batches(jobs);
for (const [index, batch] of allBatches.entries()) {
  const values = await translateBatch(batch, index);
  batch.forEach((job, i) => {
    let value = values[i];
    if (job.restore) {
      const decimal = job.restore.replace('.', '[.,]');
      value = value.replace(new RegExp(decimal), '{n}');
    }
    if (!job.category) {
      translated[job.key] = value;
    } else {
      translated[job.key] ??= {};
      translated[job.key][job.category] = value;
    }
  });
  console.log(`Translated batch ${index + 1}/${allBatches.length}`);
  await new Promise((resolve) => setTimeout(resolve, 180));
}

const merged = { ...existing, ...translated };
writeFileSync(outPath, JSON.stringify(Object.fromEntries(Object.keys(merged).sort().map((key) => [key, merged[key]])), null, 2) + '\n');
const machinePath = join(localeDir, `${locale}.machine.json`);
const machine = existsSync(machinePath) ? JSON.parse(readFileSync(machinePath, 'utf8')) : [];
writeFileSync(machinePath, JSON.stringify([...new Set([...machine, ...Object.keys(translated)])].sort(), null, 2) + '\n');
console.log(`Wrote ${Object.keys(translated).length} translations to ${outPath}. Review ${locale}.machine.json before release.`);
